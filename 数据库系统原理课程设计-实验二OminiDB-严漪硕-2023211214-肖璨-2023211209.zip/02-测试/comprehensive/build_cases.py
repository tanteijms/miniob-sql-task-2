#!/usr/bin/env python3
"""Build lab/test/comprehensive/cases.json (100 assertion cases)."""

from __future__ import annotations

import json
import os

OUT = os.path.join(os.path.dirname(__file__), "cases.json")


def c(
    id_: str,
    name: str,
    feature: str,
    sql: str,
    rows,
    *,
    setup=None,
    sort=False,
    expect_failure=False,
    setup_expected_failure=0,
):
    return {
        "id": id_,
        "name": name,
        "feature": feature,
        "setup": setup or [],
        "sql": sql,
        "rows": rows,
        "sort": sort,
        "expect_failure": expect_failure,
        "setup_expected_failure": setup_expected_failure,
    }


def build() -> list:
    cases: list = []

    # --- basic (5) ---
    cases += [
        c("comp-001", "create insert select", "basic",
          "SELECT * FROM t1;",
          [["1", "10"], ["2", "20"]],
          setup=[
              "CREATE TABLE t1(id INT, v INT);",
              "INSERT INTO t1 VALUES (1, 10);",
              "INSERT INTO t1 VALUES (2, 20);",
          ],
          sort=True),
        c("comp-002", "filter eq", "basic",
          "SELECT id FROM t1 WHERE v=20;",
          [["2"]],
          setup=["CREATE TABLE t1(id INT, v INT);", "INSERT INTO t1 VALUES (1, 10);", "INSERT INTO t1 VALUES (2, 20);"]),
        c("comp-003", "delete", "basic",
          "SELECT count(*) FROM t1;",
          [["1"]],
          setup=[
              "CREATE TABLE t1(id INT, v INT);",
              "INSERT INTO t1 VALUES (1, 10);",
              "INSERT INTO t1 VALUES (2, 20);",
              "DELETE FROM t1 WHERE id=1;",
          ]),
        c("comp-004", "arithmetic expr", "basic",
          "SELECT id, v+1 FROM t1 WHERE v+1=21;",
          [["2", "21"]],
          setup=["CREATE TABLE t1(id INT, v INT);", "INSERT INTO t1 VALUES (1, 10);", "INSERT INTO t1 VALUES (2, 20);"]),
        c("comp-005", "multi table scan", "basic",
          "SELECT a.id, b.id FROM ta a, tb b WHERE a.id=b.id ORDER BY a.id;",
          [["1", "1"], ["2", "2"]],
          setup=[
              "CREATE TABLE ta(id INT); CREATE TABLE tb(id INT);",
              "INSERT INTO ta VALUES (1); INSERT INTO ta VALUES (2);",
              "INSERT INTO tb VALUES (1); INSERT INTO tb VALUES (2);",
          ]),
    ]

    # --- drop-table (3) ---
    cases += [
        c("comp-006", "drop then recreate", "drop-table",
          "SELECT count(*) FROM dt;",
          [["2"]],
          setup=[
              "CREATE TABLE dt(id INT);",
              "INSERT INTO dt VALUES (1);",
              "DROP TABLE dt;",
              "CREATE TABLE dt(id INT);",
              "INSERT INTO dt VALUES (1); INSERT INTO dt VALUES (2);",
          ]),
        c("comp-007", "drop failure use missing", "drop-table",
          "DROP TABLE no_such;",
          [],
          expect_failure=True),
        c("comp-008", "index after recreate", "drop-table",
          "SELECT id FROM dt WHERE id=2;",
          [["2"]],
          setup=[
              "CREATE TABLE dt(id INT);",
              "CREATE INDEX i_dt ON dt(id);",
              "INSERT INTO dt VALUES (1); INSERT INTO dt VALUES (2);",
          ]),
    ]

    # --- update (7) ---
    cases += [
        c("comp-009", "update one row", "update",
          "SELECT * FROM ut ORDER BY id;",
          [["1", "100"], ["2", "2"]],
          setup=[
              "CREATE TABLE ut(id INT, v INT);",
              "INSERT INTO ut VALUES (1, 1); INSERT INTO ut VALUES (2, 2);",
              "UPDATE ut SET v=100 WHERE id=1;",
          ],
          sort=True),
        c("comp-010", "update all", "update",
          "SELECT sum(v) FROM ut;",
          [["0"]],
          setup=[
              "CREATE TABLE ut(id INT, v INT);",
              "INSERT INTO ut VALUES (1, 1); INSERT INTO ut VALUES (2, 2);",
              "UPDATE ut SET v=0;",
          ]),
        c("comp-011", "update with index", "update",
          "SELECT v FROM ut WHERE id=3;",
          [["30"]],
          setup=[
              "CREATE TABLE ut(id INT, v INT);",
              "CREATE INDEX i_ut ON ut(id);",
              "INSERT INTO ut VALUES (1,1); INSERT INTO ut VALUES (2,2); INSERT INTO ut VALUES (3,3);",
              "UPDATE ut SET v=30 WHERE id=3;",
          ]),
        c("comp-012", "update no match", "update",
          "SELECT count(*) FROM ut;",
          [["2"]],
          setup=[
              "CREATE TABLE ut(id INT, v INT);",
              "INSERT INTO ut VALUES (1, 1); INSERT INTO ut VALUES (2, 2);",
              "UPDATE ut SET v=9 WHERE id=99;",
          ]),
        c("comp-013", "update invalid table", "update",
          "UPDATE ghost SET v=1;",
          [],
          expect_failure=True),
        c("comp-014", "update char", "update",
          "SELECT name FROM ut;",
          [["new"]],
          setup=[
              "CREATE TABLE ut(id INT, name CHAR(8));",
              "INSERT INTO ut VALUES (1, 'old');",
              "UPDATE ut SET name='new' WHERE id=1;",
          ]),
        c("comp-015", "update date col", "update",
          "SELECT d FROM ut;",
          [["2021-01-02"]],
          setup=[
              "CREATE TABLE ut(id INT, d DATE);",
              "INSERT INTO ut VALUES (1, '2021-01-01');",
              "UPDATE ut SET d='2021-01-02' WHERE id=1;",
          ]),
    ]

    # --- date (7) ---
    cases += [
        c("comp-016", "date compare", "date",
          "SELECT id FROM dd WHERE d>'2020-06-01';",
          [["2"], ["3"]],
          setup=[
              "CREATE TABLE dd(id INT, d DATE);",
              "INSERT INTO dd VALUES (1, '2020-01-01');",
              "INSERT INTO dd VALUES (2, '2020-12-31');",
              "INSERT INTO dd VALUES (3, '2021-06-15');",
          ],
          sort=True),
        c("comp-017", "date invalid insert", "date",
          "INSERT INTO dd VALUES (9, '2020-13-40');",
          [],
          setup=["CREATE TABLE dd(id INT, d DATE);"],
          expect_failure=True),
        c("comp-018", "date delete", "date",
          "SELECT count(*) FROM dd;",
          [["1"]],
          setup=[
              "CREATE TABLE dd(id INT, d DATE);",
              "INSERT INTO dd VALUES (1, '2020-01-01');",
              "INSERT INTO dd VALUES (2, '2020-12-31');",
              "DELETE FROM dd WHERE id=2;",
          ]),
        c("comp-019", "date_format", "date",
          "SELECT DATE_FORMAT(d, '%Y') FROM dd;",
          [["2020"]],
          setup=["CREATE TABLE dd(id INT, d DATE);", "INSERT INTO dd VALUES (1, '2020-05-20');"]),
        c("comp-020", "date order", "date",
          "SELECT id FROM dd ORDER BY d;",
          [["1"], ["2"], ["3"]],
          setup=[
              "CREATE TABLE dd(id INT, d DATE);",
              "INSERT INTO dd VALUES (2, '2020-12-31');",
              "INSERT INTO dd VALUES (1, '2020-01-01');",
              "INSERT INTO dd VALUES (3, '2021-01-01');",
          ]),
        c("comp-021", "date eq", "date",
          "SELECT count(*) FROM dd WHERE d='2020-01-01';",
          [["1"]],
          setup=["CREATE TABLE dd(id INT, d DATE);", "INSERT INTO dd VALUES (1, '2020-01-01');", "INSERT INTO dd VALUES (2, '2021-01-01');"]),
        c("comp-022", "date update", "date",
          "SELECT d FROM dd WHERE id=1;",
          [["2022-02-02"]],
          setup=[
              "CREATE TABLE dd(id INT, d DATE);",
              "INSERT INTO dd VALUES (1, '2020-01-01');",
              "UPDATE dd SET d='2022-02-02' WHERE id=1;",
          ]),
    ]

    # --- aggregation (8) ---
    cases += [
        c("comp-023", "count star", "aggregation",
          "SELECT count(*) FROM ag;",
          [["4"]],
          setup=[
              "CREATE TABLE ag(id INT, num INT);",
              "INSERT INTO ag VALUES (1,10); INSERT INTO ag VALUES (2,20);",
              "INSERT INTO ag VALUES (3,30); INSERT INTO ag VALUES (4,40);",
          ]),
        c("comp-024", "avg", "aggregation",
          "SELECT avg(num) FROM ag;",
          [["25"]],
          setup=[
              "CREATE TABLE ag(id INT, num INT);",
              "INSERT INTO ag VALUES (1,10); INSERT INTO ag VALUES (2,20);",
              "INSERT INTO ag VALUES (3,30); INSERT INTO ag VALUES (4,40);",
          ]),
        c("comp-025", "max min", "aggregation",
          "SELECT max(num), min(num) FROM ag;",
          [["40", "10"]],
          setup=[
              "CREATE TABLE ag(id INT, num INT);",
              "INSERT INTO ag VALUES (1,10); INSERT INTO ag VALUES (2,40); INSERT INTO ag VALUES (3,30);",
          ]),
        c("comp-026", "count empty", "aggregation",
          "SELECT count(*) FROM ag;",
          [["0"]],
          setup=["CREATE TABLE ag(id INT, num INT);"]),
        c("comp-027", "sum filter", "aggregation",
          "SELECT sum(num) FROM ag WHERE id>1;",
          [["70"]],
          setup=[
              "CREATE TABLE ag(id INT, num INT);",
              "INSERT INTO ag VALUES (1,10); INSERT INTO ag VALUES (2,20); INSERT INTO ag VALUES (3,50);",
          ]),
        c("comp-028", "count distinct id", "aggregation",
          "SELECT count(id) FROM ag;",
          [["3"]],
          setup=[
              "CREATE TABLE ag(id INT, num INT);",
              "INSERT INTO ag VALUES (1,10); INSERT INTO ag VALUES (2,20); INSERT INTO ag VALUES (3,30);",
          ]),
        c("comp-029", "avg one row", "aggregation",
          "SELECT avg(num) FROM ag;",
          [["7"]],
          setup=["CREATE TABLE ag(id INT, num INT);", "INSERT INTO ag VALUES (1,7);"]),
        c("comp-030", "max empty", "aggregation",
          "SELECT max(num) FROM ag;",
          [["NULL"]],
          setup=["CREATE TABLE ag(id INT, num INT);"]),
    ]

    # --- like (5) ---
    cases += [
        c("comp-031", "like prefix", "like",
          "SELECT id FROM lk WHERE name LIKE 'ab%';",
          [["1"], ["2"]],
          setup=[
              "CREATE TABLE lk(id INT, name CHAR(10));",
              "INSERT INTO lk VALUES (1, 'abc'); INSERT INTO lk VALUES (2, 'abd'); INSERT INTO lk VALUES (3, 'xx');",
          ],
          sort=True),
        c("comp-032", "like underscore", "like",
          "SELECT id FROM lk WHERE name LIKE 'a_c';",
          [["1"]],
          setup=["CREATE TABLE lk(id INT, name CHAR(10));", "INSERT INTO lk VALUES (1, 'abc'); INSERT INTO lk VALUES (2, 'abd');"]),
        c("comp-033", "like z prefix", "like",
          "SELECT count(*) FROM lk WHERE name LIKE 'z%';",
          [["1"]],
          setup=["CREATE TABLE lk(id INT, name CHAR(10));", "INSERT INTO lk VALUES (1, 'abc'); INSERT INTO lk VALUES (2, 'zz');"]),
        c("comp-034", "like empty", "like",
          "SELECT count(*) FROM lk WHERE name LIKE 'z%';",
          [["0"]],
          setup=["CREATE TABLE lk(id INT, name CHAR(10));", "INSERT INTO lk VALUES (1, 'abc');"]),
        c("comp-035", "like escape %", "like",
          "SELECT id FROM lk WHERE name LIKE '%b%';",
          [["1"], ["2"]],
          setup=["CREATE TABLE lk(id INT, name CHAR(10));", "INSERT INTO lk VALUES (1, 'abc'); INSERT INTO lk VALUES (2, 'xbx');"],
          sort=True),
    ]

    # --- join (10) ---
    cases += [
        c("comp-036", "inner join on", "join",
          "SELECT j1.id, j2.v FROM j1 INNER JOIN j2 ON j1.id=j2.id ORDER BY j1.id;",
          [["1", "10"], ["2", "20"]],
          setup=[
              "CREATE TABLE j1(id INT); CREATE TABLE j2(id INT, v INT);",
              "INSERT INTO j1 VALUES (1); INSERT INTO j1 VALUES (2);",
              "INSERT INTO j2 VALUES (1,10); INSERT INTO j2 VALUES (2,20); INSERT INTO j2 VALUES (3,30);",
          ]),
        c("comp-037", "join no match", "join",
          "SELECT count(*) FROM j1 INNER JOIN j2 ON j1.id=j2.id WHERE j1.id=9;",
          [["0"]],
          setup=[
              "CREATE TABLE j1(id INT); CREATE TABLE j2(id INT, v INT);",
              "INSERT INTO j1 VALUES (1); INSERT INTO j2 VALUES (2,20);",
          ]),
        c("comp-038", "comma join", "join",
          "SELECT j1.id FROM j1, j2 WHERE j1.id=j2.id AND j2.v>15;",
          [["2"]],
          setup=[
              "CREATE TABLE j1(id INT); CREATE TABLE j2(id INT, v INT);",
              "INSERT INTO j1 VALUES (1); INSERT INTO j1 VALUES (2);",
              "INSERT INTO j2 VALUES (1,10); INSERT INTO j2 VALUES (2,20);",
          ]),
        c("comp-039", "three table join", "join",
          "SELECT count(*) FROM j1, j2, j3 WHERE j1.id=j2.id AND j2.id=j3.id;",
          [["2"]],
          setup=[
              "CREATE TABLE j1(id INT); CREATE TABLE j2(id INT, v INT); CREATE TABLE j3(id INT, tag INT);",
              "INSERT INTO j1 VALUES (1); INSERT INTO j1 VALUES (2);",
              "INSERT INTO j2 VALUES (1,10); INSERT INTO j2 VALUES (2,20);",
              "INSERT INTO j3 VALUES (1,1); INSERT INTO j3 VALUES (2,2);",
          ]),
        c("comp-040", "join filter", "join",
          "SELECT j2.v FROM j1 INNER JOIN j2 ON j1.id=j2.id WHERE j2.v=10;",
          [["10"]],
          setup=[
              "CREATE TABLE j1(id INT); CREATE TABLE j2(id INT, v INT);",
              "INSERT INTO j1 VALUES (1); INSERT INTO j2 VALUES (1,10); INSERT INTO j2 VALUES (2,20);",
          ]),
        c("comp-041", "self join style", "join",
          "SELECT a.id FROM j1 a, j1 b WHERE a.id=b.id;",
          [["1"], ["2"]],
          setup=["CREATE TABLE j1(id INT);", "INSERT INTO j1 VALUES (1); INSERT INTO j1 VALUES (2);"],
          sort=True),
        c("comp-042", "join agg", "join",
          "SELECT sum(j2.v) FROM j1 INNER JOIN j2 ON j1.id=j2.id;",
          [["30"]],
          setup=[
              "CREATE TABLE j1(id INT); CREATE TABLE j2(id INT, v INT);",
              "INSERT INTO j1 VALUES (1); INSERT INTO j1 VALUES (2);",
              "INSERT INTO j2 VALUES (1,10); INSERT INTO j2 VALUES (2,20);",
          ]),
        c("comp-043", "join order", "join",
          "SELECT j2.v FROM j1 INNER JOIN j2 ON j1.id=j2.id ORDER BY j2.v DESC;",
          [["20"], ["10"]],
          setup=[
              "CREATE TABLE j1(id INT); CREATE TABLE j2(id INT, v INT);",
              "INSERT INTO j1 VALUES (1); INSERT INTO j1 VALUES (2);",
              "INSERT INTO j2 VALUES (1,10); INSERT INTO j2 VALUES (2,20);",
          ]),
        c("comp-044", "join one row", "join",
          "SELECT j1.id, j2.v FROM j1 INNER JOIN j2 ON j1.id=j2.id WHERE j1.id=1;",
          [["1", "10"]],
          setup=[
              "CREATE TABLE j1(id INT); CREATE TABLE j2(id INT, v INT);",
              "INSERT INTO j1 VALUES (1); INSERT INTO j2 VALUES (1,10); INSERT INTO j2 VALUES (2,20);",
          ]),
        c("comp-045", "join duplicate key", "join",
          "SELECT count(*) FROM j1 INNER JOIN j2 ON j1.id=j2.id;",
          [["2"]],
          setup=[
              "CREATE TABLE j1(id INT); CREATE TABLE j2(id INT, v INT);",
              "INSERT INTO j1 VALUES (1); INSERT INTO j2 VALUES (1,10); INSERT INTO j2 VALUES (1,11);",
          ]),
    ]

    # --- function (7) ---
    cases += [
        c("comp-046", "length", "function",
          "SELECT LENGTH(name) FROM fn;",
          [["3"]],
          setup=["CREATE TABLE fn(id INT, name CHAR(10));", "INSERT INTO fn VALUES (1, 'abc');"]),
        c("comp-047", "round", "function",
          "SELECT ROUND(score) FROM fn;",
          [["3"]],
          setup=["CREATE TABLE fn(id INT, score FLOAT);", "INSERT INTO fn VALUES (1, 2.6);"]),
        c("comp-048", "round score filter", "function",
          "SELECT id FROM fn WHERE ROUND(score)=3;",
          [["1"]],
          setup=["CREATE TABLE fn(id INT, score FLOAT);", "INSERT INTO fn VALUES (1, 2.6);", "INSERT INTO fn VALUES (2, 1.2);"]),
        c("comp-049", "expr mix", "function",
          "SELECT id+1 FROM fn;",
          [["2"]],
          setup=["CREATE TABLE fn(id INT, f FLOAT);", "INSERT INTO fn VALUES (1, 1.0);"]),
        c("comp-050", "date_format fn", "function",
          "SELECT DATE_FORMAT(d, '%D,%M,%Y') FROM fn;",
          [["20th,June,2020"]],
          setup=["CREATE TABLE fn(id INT, d DATE);", "INSERT INTO fn VALUES (1, '2020-06-20');"]),
        c("comp-051", "length filter", "function",
          "SELECT id FROM fn WHERE LENGTH(name)>2;",
          [["2"]],
          setup=[
              "CREATE TABLE fn(id INT, name CHAR(10));",
              "INSERT INTO fn VALUES (1, 'ab'); INSERT INTO fn VALUES (2, 'abcd');",
          ]),
        c("comp-052", "invalid func", "function",
          "SELECT NOPE(x) FROM fn;",
          [],
          setup=["CREATE TABLE fn(id INT, x INT);", "INSERT INTO fn VALUES (1,1);"],
          expect_failure=True),
    ]

    # --- order-by (6) ---
    cases += [
        c("comp-053", "order asc", "order-by",
          "SELECT id FROM ob ORDER BY v;",
          [["1"], ["2"], ["3"]],
          setup=[
              "CREATE TABLE ob(id INT, v INT);",
              "INSERT INTO ob VALUES (2,20); INSERT INTO ob VALUES (1,10); INSERT INTO ob VALUES (3,30);",
          ]),
        c("comp-054", "order desc", "order-by",
          "SELECT v FROM ob ORDER BY v DESC;",
          [["30"], ["20"], ["10"]],
          setup=[
              "CREATE TABLE ob(id INT, v INT);",
              "INSERT INTO ob VALUES (2,20); INSERT INTO ob VALUES (1,10); INSERT INTO ob VALUES (3,30);",
          ]),
        c("comp-055", "multi order", "order-by",
          "SELECT id, k FROM ob ORDER BY k DESC, id ASC;",
          [["2", "2"], ["3", "2"], ["1", "1"]],
          setup=[
              "CREATE TABLE ob(id INT, v INT, k INT);",
              "INSERT INTO ob VALUES (1,10,1); INSERT INTO ob VALUES (2,20,2); INSERT INTO ob VALUES (3,30,2);",
          ]),
        c("comp-056", "order with where", "order-by",
          "SELECT id FROM ob WHERE v>10 ORDER BY id;",
          [["2"], ["3"]],
          setup=[
              "CREATE TABLE ob(id INT, v INT);",
              "INSERT INTO ob VALUES (1,10); INSERT INTO ob VALUES (2,20); INSERT INTO ob VALUES (3,30);",
          ]),
        c("comp-057", "order char", "order-by",
          "SELECT name FROM ob ORDER BY name;",
          [["aa"], ["bb"], ["cc"]],
          setup=[
              "CREATE TABLE ob(id INT, name CHAR(4));",
              "INSERT INTO ob VALUES (1,'cc'); INSERT INTO ob VALUES (2,'aa'); INSERT INTO ob VALUES (3,'bb');",
          ]),
        c("comp-058", "order top desc", "order-by",
          "SELECT id FROM ob ORDER BY v DESC;",
          [["3"], ["2"], ["1"]],
          setup=[
              "CREATE TABLE ob(id INT, v INT);",
              "INSERT INTO ob VALUES (1,10); INSERT INTO ob VALUES (2,20); INSERT INTO ob VALUES (3,30);",
          ]),
    ]

    # --- group-by (8) ---
    cases += [
        c("comp-059", "group count", "group-by",
          "SELECT k, count(*) FROM gb GROUP BY k ORDER BY k;",
          [["1", "2"], ["2", "1"]],
          setup=[
              "CREATE TABLE gb(id INT, k INT, s INT);",
              "INSERT INTO gb VALUES (1,1,10); INSERT INTO gb VALUES (2,1,20); INSERT INTO gb VALUES (3,2,30);",
          ]),
        c("comp-060", "group sum", "group-by",
          "SELECT k, sum(s) FROM gb GROUP BY k ORDER BY k;",
          [["1", "30"], ["2", "30"]],
          setup=[
              "CREATE TABLE gb(id INT, k INT, s INT);",
              "INSERT INTO gb VALUES (1,1,10); INSERT INTO gb VALUES (2,1,20); INSERT INTO gb VALUES (3,2,30);",
          ]),
        c("comp-061", "having", "group-by",
          "SELECT k, avg(s) FROM gb GROUP BY k HAVING avg(s)>15 ORDER BY k;",
          [["2", "30"]],
          setup=[
              "CREATE TABLE gb(id INT, k INT, s INT);",
              "INSERT INTO gb VALUES (1,1,10); INSERT INTO gb VALUES (2,1,20); INSERT INTO gb VALUES (3,2,30);",
          ]),
        c("comp-062", "group one", "group-by",
          "SELECT count(*) FROM gb GROUP BY k;",
          [["2"], ["1"]],
          setup=[
              "CREATE TABLE gb(id INT, k INT, s INT);",
              "INSERT INTO gb VALUES (1,1,10); INSERT INTO gb VALUES (2,1,20); INSERT INTO gb VALUES (3,2,30);",
          ],
          sort=True),
        c("comp-063", "group max", "group-by",
          "SELECT k, max(s) FROM gb GROUP BY k ORDER BY k;",
          [["1", "20"], ["2", "30"]],
          setup=[
              "CREATE TABLE gb(id INT, k INT, s INT);",
              "INSERT INTO gb VALUES (1,1,10); INSERT INTO gb VALUES (2,1,20); INSERT INTO gb VALUES (3,2,30);",
          ]),
        c("comp-064", "group empty", "group-by",
          "SELECT count(*) FROM gb GROUP BY k;",
          [],
          setup=["CREATE TABLE gb(id INT, k INT, s INT);"]),
        c("comp-065", "group by name", "group-by",
          "SELECT name, count(id) FROM gb GROUP BY name ORDER BY name;",
          [["a", "2"], ["b", "1"]],
          setup=[
              "CREATE TABLE gb(id INT, name CHAR(4), s INT);",
              "INSERT INTO gb VALUES (1,'a',1); INSERT INTO gb VALUES (2,'a',2); INSERT INTO gb VALUES (3,'b',3);",
          ]),
        c("comp-066", "having count", "group-by",
          "SELECT name FROM gb GROUP BY name HAVING count(id)>1;",
          [["a"]],
          setup=[
              "CREATE TABLE gb(id INT, name CHAR(4), s INT);",
              "INSERT INTO gb VALUES (1,'a',1); INSERT INTO gb VALUES (2,'a',2); INSERT INTO gb VALUES (3,'b',3);",
          ]),
        c("comp-067", "group avg filter", "group-by",
          "SELECT k FROM gb GROUP BY k HAVING sum(s)>25;",
          [["1"], ["2"]],
          setup=[
              "CREATE TABLE gb(id INT, k INT, s INT);",
              "INSERT INTO gb VALUES (1,1,10); INSERT INTO gb VALUES (2,1,20); INSERT INTO gb VALUES (3,2,30);",
          ],
          sort=True),
    ]

    # --- multi-index (7) ---
    cases += [
        c("comp-068", "composite index rows", "multi-index",
          "SELECT count(*) FROM mi;",
          [["2"]],
          setup=[
              "CREATE TABLE mi(id INT, k INT, v INT);",
              "CREATE INDEX i_mi ON mi(id, k);",
              "INSERT INTO mi VALUES (1,2,100); INSERT INTO mi VALUES (1,3,200);",
          ]),
        c("comp-069", "index scan all", "multi-index",
          "SELECT count(*) FROM mi;",
          [["2"]],
          setup=[
              "CREATE TABLE mi(id INT, k INT, v INT);",
              "CREATE INDEX i_mi ON mi(id, k);",
              "INSERT INTO mi VALUES (1,2,100); INSERT INTO mi VALUES (1,3,200);",
          ]),
        c("comp-070", "index after delete", "multi-index",
          "SELECT count(*) FROM mi;",
          [["1"]],
          setup=[
              "CREATE TABLE mi(id INT, k INT, v INT);",
              "CREATE INDEX i_mi ON mi(id);",
              "INSERT INTO mi VALUES (1,2,100); INSERT INTO mi VALUES (2,2,200);",
              "DELETE FROM mi WHERE id=2;",
          ]),
        c("comp-071", "index after update", "multi-index",
          "SELECT v FROM mi WHERE id=1;",
          [["99"]],
          setup=[
              "CREATE TABLE mi(id INT, k INT, v INT);",
              "CREATE INDEX i_mi ON mi(id);",
              "INSERT INTO mi VALUES (1,1,10);",
              "UPDATE mi SET v=99 WHERE id=1;",
          ]),
        c("comp-072", "secondary index lookup", "multi-index",
          "SELECT id FROM mi WHERE v=5;",
          [["2"]],
          setup=[
              "CREATE TABLE mi(id INT, k INT, v INT);",
              "CREATE INDEX i1 ON mi(id);",
              "CREATE INDEX i2 ON mi(v);",
              "INSERT INTO mi VALUES (1,1,1); INSERT INTO mi VALUES (2,2,5);",
          ]),
        c("comp-073", "order by with index", "multi-index",
          "SELECT id FROM mi ORDER BY id;",
          [["1"], ["2"]],
          setup=[
              "CREATE TABLE mi(id INT, k INT, v INT);",
              "CREATE INDEX i_mi ON mi(id, k);",
              "INSERT INTO mi VALUES (2,2,2); INSERT INTO mi VALUES (1,1,1);",
          ]),
        c("comp-074", "max v with index", "multi-index",
          "SELECT max(v) FROM mi;",
          [["200"]],
          setup=[
              "CREATE TABLE mi(id INT, k INT, v INT);",
              "CREATE INDEX i_mi ON mi(id, k);",
              "INSERT INTO mi VALUES (1,1,1); INSERT INTO mi VALUES (2,2,200);",
          ]),
    ]

    # --- unique (6) ---
    cases += [
        c("comp-075", "unique ok", "unique",
          "SELECT count(*) FROM uq;",
          [["3"]],
          setup=[
              "CREATE TABLE uq(id INT, v INT);",
              "CREATE UNIQUE INDEX ui ON uq(v);",
              "INSERT INTO uq VALUES (1,10); INSERT INTO uq VALUES (2,20); INSERT INTO uq VALUES (3,30);",
          ]),
        c("comp-076", "unique dup fail", "unique",
          "INSERT INTO unique_table VALUES (1, 2, 1);",
          [],
          setup=[
              "CREATE TABLE unique_table(id INT, col1 INT, col2 INT);",
              "INSERT INTO unique_table VALUES (1, 1, 1);",
              "CREATE UNIQUE INDEX index_id ON unique_table(id);",
          ],
          expect_failure=True),
        c("comp-077", "unique update dup", "unique",
          "UPDATE uq SET v=20 WHERE id=1;",
          [],
          setup=[
              "CREATE TABLE uq(id INT, v INT);",
              "CREATE UNIQUE INDEX ui ON uq(v);",
              "INSERT INTO uq VALUES (1,10); INSERT INTO uq VALUES (2,20);",
          ],
          expect_failure=True),
        c("comp-078", "unique update ok", "unique",
          "SELECT v FROM uq WHERE id=1;",
          [["15"]],
          setup=[
              "CREATE TABLE uq(id INT, v INT);",
              "CREATE UNIQUE INDEX ui ON uq(v);",
              "INSERT INTO uq VALUES (1,10); INSERT INTO uq VALUES (2,20);",
              "UPDATE uq SET v=15 WHERE id=1;",
          ]),
        c("comp-079", "unique delete reinsert", "unique",
          "SELECT count(*) FROM uq;",
          [["2"]],
          setup=[
              "CREATE TABLE uq(id INT, v INT);",
              "CREATE UNIQUE INDEX ui ON uq(v);",
              "INSERT INTO uq VALUES (1,10); INSERT INTO uq VALUES (2,20);",
              "DELETE FROM uq WHERE id=1;",
              "INSERT INTO uq VALUES (3,10);",
          ]),
        c("comp-080", "unique null single", "unique",
          "SELECT count(*) FROM uq;",
          [["1"]],
          setup=[
              "CREATE TABLE uq(id INT, v INT NULL);",
              "CREATE UNIQUE INDEX ui ON uq(v);",
              "INSERT INTO uq VALUES (1,null);",
          ]),
    ]

    # --- simple-sub-query (8) ---
    cases += [
        c("comp-081", "in subquery", "simple-sub-query",
          "SELECT id FROM s1 WHERE id IN (SELECT id FROM s2);",
          [["1"], ["2"]],
          setup=[
              "CREATE TABLE s1(id INT, c INT); CREATE TABLE s2(id INT, c INT);",
              "INSERT INTO s1 VALUES (1,4); INSERT INTO s1 VALUES (2,2); INSERT INTO s1 VALUES (3,3);",
              "INSERT INTO s2 VALUES (1,2); INSERT INTO s2 VALUES (2,7);",
          ],
          sort=True),
        c("comp-082", "not in subquery", "simple-sub-query",
          "SELECT id FROM s1 WHERE c NOT IN (SELECT c FROM s2) ORDER BY id;",
          [["1"], ["3"]],
          setup=[
              "CREATE TABLE s1(id INT, c INT); CREATE TABLE s2(id INT, c INT);",
              "INSERT INTO s1 VALUES (1,4); INSERT INTO s1 VALUES (2,2); INSERT INTO s1 VALUES (3,3);",
              "INSERT INTO s2 VALUES (1,2); INSERT INTO s2 VALUES (2,7);",
          ]),
        c("comp-083", "scalar subquery eq int", "simple-sub-query",
          "SELECT id FROM s1 WHERE c=(SELECT max(c) FROM s2);",
          [["1"]],
          setup=[
              "CREATE TABLE s1(id INT, c INT); CREATE TABLE s2(id INT, c INT);",
              "INSERT INTO s1 VALUES (1,7); INSERT INTO s1 VALUES (2,2);",
              "INSERT INTO s2 VALUES (1,2); INSERT INTO s2 VALUES (2,7);",
          ]),
        c("comp-084", "scalar subquery cmp", "simple-sub-query",
          "SELECT count(*) FROM s1 WHERE c > (SELECT min(c) FROM s2);",
          [["1"]],
          setup=[
              "CREATE TABLE s1(id INT, c INT); CREATE TABLE s2(id INT, c INT);",
              "INSERT INTO s1 VALUES (1,4); INSERT INTO s1 VALUES (2,2); INSERT INTO s1 VALUES (3,1);",
              "INSERT INTO s2 VALUES (1,2); INSERT INTO s2 VALUES (2,7);",
          ]),
        c("comp-085", "empty in", "simple-sub-query",
          "SELECT count(*) FROM s1 WHERE id IN (SELECT id FROM s2 WHERE 1=0);",
          [["0"]],
          setup=[
              "CREATE TABLE s1(id INT, c INT); CREATE TABLE s2(id INT, c INT);",
              "INSERT INTO s1 VALUES (1,1); INSERT INTO s2 VALUES (1,1);",
          ]),
        c("comp-086", "scalar multi fail", "simple-sub-query",
          "SELECT * FROM s1 WHERE c=(SELECT c FROM s2);",
          [],
          setup=[
              "CREATE TABLE s1(id INT, c INT); CREATE TABLE s2(id INT, c INT);",
              "INSERT INTO s1 VALUES (1,1); INSERT INTO s2 VALUES (1,2); INSERT INTO s2 VALUES (2,3);",
          ],
          expect_failure=True),
        c("comp-087", "select star in fail", "simple-sub-query",
          "SELECT * FROM s1 WHERE c IN (SELECT * FROM s2);",
          [],
          setup=[
              "CREATE TABLE s1(id INT, c INT); CREATE TABLE s2(id INT, x INT);",
              "INSERT INTO s1 VALUES (1,1); INSERT INTO s2 VALUES (1,2);",
          ],
          expect_failure=True),
        c("comp-088", "agg scalar subquery", "simple-sub-query",
          "SELECT id FROM s1 WHERE c >= (SELECT max(c) FROM s2);",
          [["1"]],
          setup=[
              "CREATE TABLE s1(id INT, c INT); CREATE TABLE s2(id INT, c INT);",
              "INSERT INTO s1 VALUES (1,9); INSERT INTO s1 VALUES (2,5);",
              "INSERT INTO s2 VALUES (1,3); INSERT INTO s2 VALUES (2,7);",
          ]),
    ]

    # --- complex-sub-query (8) ---
    cases += [
        c("comp-089", "nested in", "complex-sub-query",
          "SELECT count(*) FROM c1 WHERE id IN (SELECT id FROM c2 WHERE id IN (SELECT id FROM c3));",
          [["1"]],
          setup=[
              "CREATE TABLE c1(id INT); CREATE TABLE c2(id INT); CREATE TABLE c3(id INT);",
              "INSERT INTO c1 VALUES (1); INSERT INTO c1 VALUES (2);",
              "INSERT INTO c2 VALUES (1); INSERT INTO c2 VALUES (3);",
              "INSERT INTO c3 VALUES (1);",
          ]),
        c("comp-090", "nested scalar", "complex-sub-query",
          "SELECT count(*) FROM c1 WHERE id >= (SELECT min(id) FROM c2 WHERE id IN (SELECT id FROM c3));",
          [["1"]],
          setup=[
              "CREATE TABLE c1(id INT); CREATE TABLE c2(id INT); CREATE TABLE c3(id INT);",
              "INSERT INTO c1 VALUES (1); INSERT INTO c1 VALUES (2);",
              "INSERT INTO c2 VALUES (1); INSERT INTO c2 VALUES (2);",
              "INSERT INTO c3 VALUES (2);",
          ]),
        c("comp-091", "correlated scalar", "complex-sub-query",
          "SELECT count(*) FROM c1 WHERE id IN (SELECT id FROM c2 WHERE c2.tag > c1.id);",
          [["1"]],
          setup=[
              "CREATE TABLE c1(id INT); CREATE TABLE c2(id INT, tag INT);",
              "INSERT INTO c1 VALUES (1); INSERT INTO c1 VALUES (2);",
              "INSERT INTO c2 VALUES (1,5); INSERT INTO c2 VALUES (2,1);",
          ]),
        c("comp-092", "correlated in", "complex-sub-query",
          "SELECT id FROM c1 WHERE id NOT IN (SELECT id FROM c2 WHERE c2.tag <> c1.id);",
          [["1"]],
          setup=[
              "CREATE TABLE c1(id INT); CREATE TABLE c2(id INT, tag INT);",
              "INSERT INTO c1 VALUES (1); INSERT INTO c1 VALUES (2);",
              "INSERT INTO c2 VALUES (1,1); INSERT INTO c2 VALUES (2,9);",
          ]),
        c("comp-093", "double subquery and", "complex-sub-query",
          "SELECT count(*) FROM c1 WHERE id IN (SELECT id FROM c2) AND id IN (SELECT id FROM c3);",
          [["1"]],
          setup=[
              "CREATE TABLE c1(id INT); CREATE TABLE c2(id INT); CREATE TABLE c3(id INT);",
              "INSERT INTO c1 VALUES (1); INSERT INTO c1 VALUES (2);",
              "INSERT INTO c2 VALUES (1); INSERT INTO c2 VALUES (2);",
              "INSERT INTO c3 VALUES (1);",
          ]),
        c("comp-094", "empty nested", "complex-sub-query",
          "SELECT count(*) FROM c1 WHERE id IN (SELECT id FROM c2 WHERE id IN (SELECT id FROM c3 WHERE 1=0));",
          [["0"]],
          setup=[
              "CREATE TABLE c1(id INT); CREATE TABLE c2(id INT); CREATE TABLE c3(id INT);",
              "INSERT INTO c1 VALUES (1); INSERT INTO c2 VALUES (1); INSERT INTO c3 VALUES (1);",
          ]),
        c("comp-095", "correlated agg", "complex-sub-query",
          "SELECT id FROM c1 WHERE id IN (SELECT id FROM c2 WHERE c2.tag >= (SELECT min(tag) FROM c2 WHERE id=c1.id));",
          [["1"], ["2"]],
          setup=[
              "CREATE TABLE c1(id INT); CREATE TABLE c2(id INT, tag INT);",
              "INSERT INTO c1 VALUES (1); INSERT INTO c1 VALUES (2);",
              "INSERT INTO c2 VALUES (1,3); INSERT INTO c2 VALUES (1,5); INSERT INTO c2 VALUES (2,1);",
          ],
          sort=True),
        c("comp-096", "not in correlated", "complex-sub-query",
          "SELECT count(*) FROM c1 WHERE id NOT IN (SELECT id FROM c2 WHERE c2.tag = c1.id);",
          [["0"]],
          setup=[
              "CREATE TABLE c1(id INT); CREATE TABLE c2(id INT, tag INT);",
              "INSERT INTO c1 VALUES (1); INSERT INTO c1 VALUES (2);",
              "INSERT INTO c2 VALUES (1,1); INSERT INTO c2 VALUES (2,2);",
          ]),
    ]

    # --- update-select (7) ---
    cases += [
        c("comp-097", "update scalar subquery", "update-select",
          "SELECT val FROM us ORDER BY id;",
          [["100"], ["100"]],
          setup=[
              "CREATE TABLE us(id INT, val INT);",
              "CREATE TABLE ref(id INT, score INT);",
              "INSERT INTO us VALUES (1, 0); INSERT INTO us VALUES (2, 0);",
              "INSERT INTO ref VALUES (1, 100); INSERT INTO ref VALUES (2, 200);",
              "UPDATE us SET val = (SELECT score FROM ref WHERE ref.id = 1);",
          ],
          sort=True),
        c("comp-098", "update scalar subquery where", "update-select",
          "SELECT val FROM us WHERE id=2;",
          [["20"]],
          setup=[
              "CREATE TABLE us(id INT, val INT);",
              "CREATE TABLE ref(id INT, score INT);",
              "INSERT INTO us VALUES (1, 0);",
              "INSERT INTO us VALUES (2, 0);",
              "INSERT INTO ref VALUES (1, 10);",
              "INSERT INTO ref VALUES (2, 20);",
              "UPDATE us SET val=(SELECT score FROM ref WHERE ref.id=2) WHERE id=2;",
          ]),
        c("comp-099", "update correlated", "update-select",
          "SELECT val FROM us ORDER BY id;",
          [["10"], ["20"]],
          setup=[
              "CREATE TABLE us(id INT, val INT);",
              "CREATE TABLE ref(id INT, score INT);",
              "INSERT INTO us VALUES (1, 0); INSERT INTO us VALUES (2, 0);",
              "INSERT INTO ref VALUES (1, 10); INSERT INTO ref VALUES (2, 20);",
              "UPDATE us SET val = (SELECT score FROM ref WHERE ref.id = us.id);",
          ],
          sort=True),
        c("comp-100a", "update literal expr", "update-select",
          "SELECT val FROM us WHERE id=1;",
          [["99"]],
          setup=[
              "CREATE TABLE us(id INT, val INT);",
              "INSERT INTO us VALUES (1, 1);",
              "UPDATE us SET val = 99 WHERE id = 1;",
          ]),
        c("comp-100b", "update multi row scalar fail", "update-select",
          "UPDATE us SET val = (SELECT score FROM ref);",
          [],
          setup=[
              "CREATE TABLE us(id INT, val INT);",
              "CREATE TABLE ref(id INT, score INT);",
              "INSERT INTO us VALUES (1, 0);",
              "INSERT INTO ref VALUES (1, 1); INSERT INTO ref VALUES (2, 2);",
          ],
          expect_failure=True),
        c("comp-100c", "update where filter", "update-select",
          "SELECT val FROM us ORDER BY id;",
          [["0"], ["5"]],
          setup=[
              "CREATE TABLE us(id INT, val INT);",
              "INSERT INTO us VALUES (1, 0); INSERT INTO us VALUES (2, 0);",
              "UPDATE us SET val = 5 WHERE id = 2;",
          ],
          sort=True),
        c("comp-100d", "update rollback unique", "update-select",
          "SELECT val FROM us ORDER BY id;",
          [["10"], ["20"], ["15"]],
          setup=[
              "CREATE TABLE us(id INT, val INT);",
              "CREATE UNIQUE INDEX ius ON us(val);",
              "INSERT INTO us VALUES (1, 10); INSERT INTO us VALUES (2, 20); INSERT INTO us VALUES (3, 15);",
              "UPDATE us SET val = (SELECT 20);",
          ],
          sort=True),
    ]

    # --- null (6) ---
    cases += [
        c("comp-101", "is null", "null",
          "SELECT id FROM nt WHERE num IS NULL ORDER BY id;",
          [["2"], ["4"]],
          setup=[
              "CREATE TABLE nt(id INT NOT NULL, num INT NULL, price FLOAT NOT NULL);",
              "INSERT INTO nt VALUES (1, 18, 10.0);",
              "INSERT INTO nt VALUES (2, null, 20.0);",
              "INSERT INTO nt VALUES (3, 12, 30.0);",
              "INSERT INTO nt VALUES (4, null, 40.0);",
          ]),
        c("comp-102", "is not null", "null",
          "SELECT count(*) FROM nt WHERE num IS NOT NULL;",
          [["2"]],
          setup=[
              "CREATE TABLE nt(id INT NOT NULL, num INT NULL, price FLOAT NOT NULL);",
              "INSERT INTO nt VALUES (1, 18, 10.0); INSERT INTO nt VALUES (2, null, 20.0); INSERT INTO nt VALUES (3, 12, 30.0);",
          ]),
        c("comp-103", "null eq unknown", "null",
          "SELECT count(*) FROM nt WHERE num = null;",
          [["0"]],
          setup=[
              "CREATE TABLE nt(id INT NOT NULL, num INT NULL, price FLOAT NOT NULL);",
              "INSERT INTO nt VALUES (1, 18, 10.0); INSERT INTO nt VALUES (2, null, 20.0);",
          ]),
        c("comp-104", "not null insert fail", "null",
          "INSERT INTO nt VALUES (5, 1, null);",
          [],
          setup=["CREATE TABLE nt(id INT NOT NULL, num INT NULL, price FLOAT NOT NULL);"],
          expect_failure=True),
        c("comp-105", "null id insert fail", "null",
          "INSERT INTO nt VALUES (null, 1, 1.0);",
          [],
          setup=["CREATE TABLE nt(id INT NOT NULL, num INT NULL, price FLOAT NOT NULL);"],
          expect_failure=True),
        c("comp-106", "count num skip null", "null",
          "SELECT count(num) FROM nt;",
          [["2"]],
          setup=[
              "CREATE TABLE nt(id INT NOT NULL, num INT NULL, price FLOAT NOT NULL);",
              "INSERT INTO nt VALUES (1, 1, 1.0); INSERT INTO nt VALUES (2, null, 2.0); INSERT INTO nt VALUES (3, 3, 3.0);",
          ]),
    ]

    # --- integration (4) ---
    cases += [
        c("comp-107", "join group having", "integration",
          "SELECT j1.k, sum(j2.v) FROM j1 INNER JOIN j2 ON j1.id=j2.id GROUP BY j1.k HAVING sum(j2.v)>10 ORDER BY j1.k;",
          [["2", "30"]],
          setup=[
              "CREATE TABLE j1(id INT, k INT); CREATE TABLE j2(id INT, v INT);",
              "INSERT INTO j1 VALUES (1,1); INSERT INTO j1 VALUES (2,2);",
              "INSERT INTO j2 VALUES (1,5); INSERT INTO j2 VALUES (2,15); INSERT INTO j2 VALUES (2,15);",
          ]),
        c("comp-108", "subquery null mix", "integration",
          "SELECT count(*) FROM nt WHERE num IN (SELECT num FROM nt2 WHERE num IS NOT NULL);",
          [["1"]],
          setup=[
              "CREATE TABLE nt(id INT NOT NULL, num INT NULL);",
              "CREATE TABLE nt2(id INT NOT NULL, num INT NULL);",
              "INSERT INTO nt VALUES (1, 10); INSERT INTO nt VALUES (2, null);",
              "INSERT INTO nt2 VALUES (1, 10); INSERT INTO nt2 VALUES (2, null);",
          ]),
        c("comp-109", "index order limit rows", "integration",
          "SELECT id FROM mi WHERE k>0 ORDER BY id DESC;",
          [["3"], ["2"], ["1"]],
          setup=[
              "CREATE TABLE mi(id INT, k INT);",
              "CREATE INDEX i_mi ON mi(id, k);",
              "INSERT INTO mi VALUES (1,1); INSERT INTO mi VALUES (2,2); INSERT INTO mi VALUES (3,3);",
          ]),
        c("comp-110", "date filter after update", "integration",
          "SELECT id FROM dd WHERE d > '2020-12-31';",
          [["2"]],
          setup=[
              "CREATE TABLE dd(id INT, d DATE);",
              "INSERT INTO dd VALUES (1, '2020-01-01'); INSERT INTO dd VALUES (2, '2021-06-01');",
              "UPDATE dd SET d='2021-12-01' WHERE id=2;",
          ]),
    ]

    # trim to 100: drop 10 lighter cases from the front/middle
    drop_ids = {
        "comp-005", "comp-007", "comp-013", "comp-027", "comp-030",
        "comp-034", "comp-041", "comp-044", "comp-049", "comp-056",
        "comp-029", "comp-028", "comp-062",
    }
    cases = [x for x in cases if x["id"] not in drop_ids]
    return cases


def main():
    cases = build()
    if len(cases) != 100:
        raise SystemExit(f"expected 100 cases, got {len(cases)} (adjust drop_ids)")

    for case in cases:
        setup: list = []
        for line in case.get("setup") or []:
            for frag in line.split(";"):
                frag = frag.strip()
                if frag:
                    setup.append(frag)
        case["setup"] = setup

    # MiniOB date display omits zero padding
    date_fix = {
        "2021-01-02": "2021-1-2",
        "2022-02-02": "2022-2-2",
    }
    for case in cases:
        fixed = []
        for row in case.get("rows", []):
            fixed.append([date_fix.get(c, c) for c in row])
        case["rows"] = fixed

    doc = {
        "version": 1,
        "description": "100 per-case assertion tests for MiniOB feature coverage",
        "cases": cases,
    }
    with open(OUT, "w", encoding="utf-8") as f:
        json.dump(doc, f, ensure_ascii=False, indent=2)
    print(f"wrote {len(cases)} cases to {OUT}")


if __name__ == "__main__":
    main()
