CREATE TABLE unique_table(id int, col1 int, col2 int);
INSERT INTO unique_table VALUES (1, 1, 1);

CREATE UNIQUE INDEX index_id ON unique_table(id);
INSERT INTO unique_table VALUES (2, 1, 1);
CREATE UNIQUE INDEX index_id ON unique_table(id);
INSERT INTO unique_table VALUES (3, 2, 1);
INSERT INTO unique_table VALUES (1, 2, 1);

SELECT * FROM unique_table;
