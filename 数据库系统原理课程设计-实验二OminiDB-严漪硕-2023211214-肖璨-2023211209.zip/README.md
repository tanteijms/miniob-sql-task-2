# 课程设计提交材料包

> 本目录为**提交用副本**（`cp` 复制，仓库原文件未移动）。  
> 完整可编译工程仍以仓库根目录为准；此处便于老师离线查阅报告、日志、改动源码与测试资产。

---

## 目录说明

| 目录 | 内容 |
|------|------|
| [`01-实验报告/`](./01-实验报告/) | 课程设计报告 Markdown + PDF |
| [`02-测试/`](./02-测试/) | 全量回归结果、用例清单、自定义 SQL、官方 primary、压力脚本 |
| [`03-开发日志/`](./03-开发日志/) | 分题开发日志（`yys-dev/`、`xc/`） |
| [`04-内核改动源码/`](./04-内核改动源码/) | 相对上游 MiniOB **有改动的 `src/` 文件快照** + 清单 |
| [`05-验收前端/`](./05-验收前端/) | 浏览器答辩演示（Node 代理 + 预设 SQL） |
| [`06-辅助文档/`](./06-辅助文档/) | 架构图、启动说明、报告插图 Mermaid 源、AI 上下文索引 |
| [`07-说明/`](./07-说明/) | Git 版本信息 |

---

## 实现范围（18 / 25 题）

已实现：basic, date, drop-table, update, aggregation-func, like, join-tables, simple-sub-query, function, multi-index, unique, null, update-select, expression, order-by, group-by, complex-sub-query, big-query, big-write。

未实现：alias, text, create-view, create-table-select, update-mvcc, big-order-by。

---

## 测试结果摘要

来源：[`02-测试/latest.md`](./02-测试/latest.md)（复制时快照）

| 指标 | 数值 |
|------|------|
| 用例总数 | 135 |
| 通过 | 135 |
| 失败 | 0 |
| 通过率 | 100.0% |

构成：14 官方 primary + 18 自定义 SQL + 100 综合断言 + 3 压力测试。

---

## 如何复现（在完整仓库根目录）

```bash
# 编译
bash build.sh debug --make -j8

# 全量回归
python3 lab/test/run_all.py

# 启动 observer
build_debug/bin/observer -f etc/observer.ini -p 6789 -P plain

# 答辩前端
node lab/frontend/server.js
# 浏览器 http://127.0.0.1:3001
```

---

## 04-内核改动源码 说明

- 仅包含本课题**实际修改过**的 `src/observer/` 等文件，非完整 MiniOB 源码树。
- 完整工程需 clone 本 Git 仓库并在根目录编译。
- 文件列表见 [`04-内核改动源码/改动文件清单.txt`](./04-内核改动源码/改动文件清单.txt)。
- Git 快照见 [`07-说明/git版本信息.txt`](./07-说明/git版本信息.txt)。

---

## 开发日志阅读顺序（建议）

**按题目主线（yys-dev）**

1. `01` 环境与 drop-table → `02` update → `03` date → `04` aggregation  
2. `05` like → `06` join → `07` function → `08` order-by → `09` group-by  
3. `10` multi-index → `13` unique → `14`~`16` 子查询 → `17` null  
4. `18` update-select → `19` big-query → `12` big-write → `20` 全量测试报告  

**XC 工作区补充（xc）**

- null、simple-sub-query、update-select、big-query、frontend、实验报告增强

---

## 材料清单（文件数）

复制完成后可在仓库根目录执行：

```bash
find lab/提交 -type f | wc -l
```

---

*打包时间：2026-06-15 · 材料均为 copy 副本，修改请仍在原路径进行后再重新复制本目录。*
